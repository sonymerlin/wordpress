=== Ultimate Reviews Rocket ===

Contributors: wsxplugindev
Donate link: https://www.webstix.com/payment
Plugin Name: Ultimate Reviews Rocket
Plugin URI:  https://www.webstix.com/wordpress-plugin-development
Tags: wp, reviews, feedback, form
Author URI: https://www.webstix.com/
Author: Webstix
Requires at least: 5.4
Tested up to: 5.8.2
Stable tag: 1.0.0
Version: 1.0.0
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Have your customers give you reviews to rate your service and make sure only the good ones are posted on social media or where you want. Capture low ratings and ask for feedback to help make sure your customers are happy and so bad reviews don't see the light of day.

== Installation ==

Option 1:

1. Install the plugin in the Dashboard => Plugins menu => Add New => Upload => Select the zip file => Install Now
2. Activate plugin in the Dashboard => Plugins menu
3. After activating the plugin, it redirects you to the plugin's Settings page. Please fill in the required information and save the settings.

Option 2:

1. Upload the 'ultimate-reviews-rocket' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Upgrade Notice ==

Upgrades will not affect the plugin

== Frequently Asked Questions ==

= After activating the plugin what should I do? =

You will be redirected to the settings screen to complete all the tabs


== Screenshots ==

1. screenshot-1.png
2. screenshot-2.png
3. screenshot-3.png
4. screenshot-4.png
5. screenshot-5.png


== Changelog ==

= 1.0 =
* Initial Release -- December 2021

